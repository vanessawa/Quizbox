# Quizbox 📦

The most slim MVP for the quizbox of Coding Bootcamps Europe.
